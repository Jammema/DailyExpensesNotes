package com.bipul.dailyexpensesnote.utill;

public class SharedPref {

    public static final String SHARED_PREFERENCE_NAME="AELData";
    public static final String IS_FIRST_TIME_LAUNCH = "IsFirstTimeLaunch";

}
